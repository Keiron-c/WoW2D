package wow.game.objects.entity;

/**
 * The different setting types within an entity's file.
 * @author Xolitude (October 26, 2018)
 *
 */
public class EntitySettingType {

	public static final int Initialization = 0;
}
